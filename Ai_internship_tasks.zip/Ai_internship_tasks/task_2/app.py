import sys
import os
import subprocess
import importlib.util
import logging
import re
import traceback
import time

REQUIRED_PACKAGES = ["streamlit", "scikit-learn", "nltk"]

def install_missing_packages(packages):
    for package in packages:
        try:
            if importlib.util.find_spec(package) is None:
                subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        except Exception as err:
            message = f"Package install failed for '{package}': {err}"
            print(message)
            try:
                with open("app_error.log", "a", encoding="utf-8") as error_log:
                    error_log.write(message + "\n")
            except Exception:
                pass

install_missing_packages(REQUIRED_PACKAGES)

try:
    import streamlit as st
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    import nltk
    from nltk.corpus import stopwords
    from nltk.stem import WordNetLemmatizer
except Exception as err:
    print("Critical imports failed. Please verify your Python environment and rerun the app.")
    print(err)
    sys.exit(1)

st.set_page_config(
    page_title="Medical & Fitness FAQ Chatbot", 
    page_icon="💚", 
    layout="wide"
)

logger = logging.getLogger("medical_fitness_faq_bot")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.FileHandler("app_error.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s - %(levelname)s - %(message)s"))
    logger.addHandler(handler)

DEFAULT_STOPWORDS = {
    "a", "about", "above", "after", "again", "against", "all", "am", "an", "and", "any", "are", "as",
    "at", "be", "because", "been", "before", "being", "below", "between", "both", "but", "by", "can",
    "cannot", "could", "did", "do", "does", "doing", "down", "during", "each", "few", "for",
    "further", "had", "has", "have", "having", "he", "her", "here", "hers", "herself", "him", "himself",
    "his", "how", "i", "if", "in", "into", "is", "it", "its", "itself", "just", "me", "more", "most",
    "my", "myself", "no", "nor", "not", "now", "of", "off", "on", "once", "only", "or", "other",
    "ought", "our", "ours", "ourselves", "out", "over", "own", "same", "she", "should", "so", "some",
    "such", "than", "that", "the", "their", "theirs", "them", "themselves", "then", "there", "these",
    "they", "this", "those", "through", "to", "too", "under", "until", "up", "very", "was", "we", "were",
    "what", "when", "where", "which", "while", "who", "whom", "why", "will", "with", "would", "you",
    "your", "yours", "yourself", "yourselves"
}

nltk_available = False
lemmatizer = None
stop_words = DEFAULT_STOPWORDS

def initialize_nlp_resources():
    global nltk_available, lemmatizer, stop_words
    try:
        nltk.download("punkt", quiet=True)
        nltk.download("stopwords", quiet=True)
        nltk.download("wordnet", quiet=True)
        nltk.download("omw-1.4", quiet=True)
        nltk.data.find("tokenizers/punkt")
        stop_words = set(stopwords.words("english"))
        lemmatizer = WordNetLemmatizer()
        nltk_available = True
    except Exception as err:
        nltk_available = False
        logger.warning("NLTK resource initialization failed. Falling back to lightweight tokenizer. %s", err)
        stop_words = DEFAULT_STOPWORDS
        lemmatizer = None

initialize_nlp_resources()

FAQ_DATA = [
    {"question": "What are the symptoms of dehydration?", "answer": "Common dehydration symptoms include thirst, dry mouth, dark urine, dizziness, and fatigue. If you experience severe symptoms, seek medical attention promptly.", "category": "General Health"},
    {"question": "How much protein do I need daily?", "answer": "Most adults benefit from about 0.8 to 1 gram of protein per kilogram of body weight per day. Active individuals and athletes may require more, depending on training goals.", "category": "Nutrition"},
    {"question": "What should I do if I sprain my ankle?", "answer": "Use R.I.C.E.: rest, ice, compression, and elevation. Avoid putting weight on the injury and consult a healthcare professional if pain or swelling persists.", "category": "Injury"},
    {"question": "Is it safe to exercise while pregnant?", "answer": "Many people can exercise safely during pregnancy with low-impact activities like walking, swimming, and prenatal yoga, but always consult your doctor first.", "category": "General Health"},
    {"question": "How can I manage stress with fitness?", "answer": "Regular exercise, deep breathing, stretching, and mindful walks can all reduce stress. Aim for consistent movement and restful sleep for best results.", "category": "Mental Wellness"},
    {"question": "What are healthy pre-workout snacks?", "answer": "Choose light carbohydrates and lean protein such as a banana with nut butter, yogurt with berries, or a small whole-grain wrap before training.", "category": "Nutrition"},
    {"question": "Can I lose weight without cardio?", "answer": "Yes, strength training and dietary control can support weight loss. Cardio helps with calorie burn, but a balanced routine is most effective.", "category": "Fitness"},
    {"question": "How often should I stretch after exercise?", "answer": "Stretching after every workout helps maintain mobility; hold each stretch for 20 to 30 seconds and focus on major muscle groups used during training.", "category": "Fitness"},
    {"question": "What is a balanced diet for healthy skin?", "answer": "A balanced diet rich in fruits, vegetables, healthy fats, lean protein, and water supports skin health. Antioxidant-rich foods can also protect against inflammation.", "category": "Nutrition"},
    {"question": "How much water should I drink during the day?", "answer": "A general guideline is 8 to 10 cups daily, but individual needs vary based on activity, climate, and body size. Drink more when you exercise or feel thirsty.", "category": "General Health"},
    {"question": "What should I do if I feel chest discomfort during exercise?", "answer": "Stop exercising immediately and rest. Seek medical attention if chest discomfort is severe, persistent, or accompanied by shortness of breath.", "category": "Injury"},
    {"question": "Can I build muscle with bodyweight training?", "answer": "Yes, bodyweight training can build strength and muscle when exercises are progressive and performed with good form. Increase difficulty gradually over time.", "category": "Fitness"},
    {"question": "How do I improve sleep quality naturally?", "answer": "Create a consistent bedtime routine, reduce screen time before sleep, limit caffeine after midday, and keep your bedroom cool and dark.", "category": "Mental Wellness"},
    {"question": "What is a safe way to reduce sugar intake?", "answer": "Gradually replace sugary snacks with whole foods, read labels for hidden sugar, and choose water or herbal teas instead of sugary drinks.", "category": "Nutrition"}
]

FAQ_CATEGORIES = sorted({entry["category"] for entry in FAQ_DATA})
FAQ_TEXTS = []

def log_error(user_message, error):
    try:
        logger.error("%s: %s", user_message, traceback.format_exc())
    except Exception:
        print(f"Logging failure: {user_message}")

def regex_tokenizer(text):
    return re.findall(r"\b[a-zA-Z0-9']+\b", text.lower())

def lemmatize_token(token):
    if lemmatizer is not None:
        try:
            return lemmatizer.lemmatize(token)
        except Exception:
            return token
    if token.endswith("ies"): return token[:-3] + "y"
    if token.endswith("s") and len(token) > 3: return token[:-1]
    return token

def preprocess_text(text):
    global nltk_available
    if not isinstance(text, str): return ""
    text = text.lower().strip()
    text = re.sub(r"[\r\n]+", " ", text)
    text = re.sub(r"[\u200b\u200c\u200d]+", " ", text)
    tokens = []
    if nltk_available:
        try:
            tokens = nltk.word_tokenize(text)
        except Exception as err:
            log_error("NLTK word_tokenize failed, falling back to regex tokenizer", err)
            nltk_available = False
            tokens = regex_tokenizer(text)
    else:
        tokens = regex_tokenizer(text)

    processed = []
    for token in tokens:
        token = re.sub(r"[^a-z0-9']", "", token)
        if token == "" or token in stop_words: continue
        token = lemmatize_token(token)
        if token and token not in stop_words:
            processed.append(token)
    return " ".join(processed)

vectorizer = None
faq_vectors = None

def prepare_faq_texts():
    global FAQ_TEXTS
    FAQ_TEXTS = [preprocess_text(entry["question"]) for entry in FAQ_DATA]

prepare_faq_texts()

def initialize_vectorizer():
    global vectorizer, faq_vectors
    vectorizer = TfidfVectorizer()
    faq_vectors = vectorizer.fit_transform(FAQ_TEXTS)

def get_ai_response(user_input):
    safe_fallback = "I'm not quite sure about that specific health/fitness question. Please consult a healthcare professional for accurate medical advice."
    try:
        if not isinstance(user_input, str) or not user_input.strip():
            return "I'm listening! Please ask a specific medical or fitness question."
        clean_query = preprocess_text(user_input)
        if not clean_query:
            return "I'm listening! Please ask a clear question so I can help."
        similarities = cosine_similarity(vectorizer.transform([clean_query]), faq_vectors)[0]
        best_index = int(similarities.argmax())
        best_score = float(similarities[best_index]) if similarities.size else 0.0
        if best_score >= 0.3:
            return FAQ_DATA[best_index]["answer"]
        return safe_fallback
    except Exception as err:
        log_error("Matching logic failed", err)
        return safe_fallback

def render_ekg_animation():
    ekg_html = """
    <div style="display: flex; justify-content: center; align-items: center; margin-bottom: 1.5rem; width: 100%;">
        <svg xmlns="http://www.w3.org/2000/svg" width="450" height="80" viewBox="0 0 400 100" style="background: transparent;">
            <path d="M 0 50 L 140 50 L 150 20 L 160 80 L 170 5 L 180 95 L 190 40 L 200 60 L 210 50 L 400 50" 
                  fill="none" 
                  stroke="#ff007f" 
                  stroke-width="5" 
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  style="stroke-dasharray: 1000; stroke-dashoffset: 1000; animation: drawHeartbeat 3.2s linear infinite; filter: drop-shadow(0 0 10px #ff00ff);"/>
        </svg>
        <style>
        @keyframes drawHeartbeat {
            0% { stroke-dashoffset: 1000; }
            70% { stroke-dashoffset: 0; }
            100% { stroke-dashoffset: 0; opacity: 0; }
        }
        </style>
    </div>
    """
    st.markdown(ekg_html, unsafe_allow_html=True)

def inject_custom_styles():
    background = "linear-gradient(135deg, #0d001a 0%, #1a0033 50%, #2d004d 100%)"
    surface = "rgba(35, 12, 66, 0.85)"
    text = "#f8f7ff"
    accent = "#ff007f"
    accent2 = "#ff00ff"
    secondary = "#e2ccff"
    
    custom_css = f"""
        <style>
        :root {{ color-scheme: dark; }}
        html, body, .stApp {{ background: {background} !important; color: {text} !important; }}
        
        header, [data-testid="stHeader"], [data-testid="stSidebar"] {{ display: none !important; }}
        [data-testid="stToolbar"] {{ display: none !important; }}
        #MainMenu {{ visibility: hidden !important; }}
        button[data-testid="stDeployButton"] {{ display: none !important; }}
        
        .main {{ background: transparent !important; }}
        .block-container {{ padding: 2.5rem 2.5rem 2rem 2.5rem !important; }}
        
        .neon-title h1 {{
            color: #ffffff !important;
            font-weight: 800 !important;
            letter-spacing: -0.03em;
            text-shadow: 0 0 15px {accent}, 0 0 30px {accent2};
            margin-bottom: 1.5rem !important;
            text-align: center !important;
        }}
        
        h3 {{
            color: {accent2} !important;
            text-shadow: 0 0 10px rgba(255, 0, 255, 0.4);
            font-weight: 700 !important;
        }}
        
        .category-scroll-box {{ 
            max-height: 140px !important; 
            overflow-y: auto !important; 
            padding: 12px; 
            display: flex; 
            flex-wrap: wrap; 
            gap: 10px;
            background: rgba(255, 255, 255, 0.03);
            border-radius: 14px;
            border: 1px solid rgba(255, 0, 255, 0.3);
            box-shadow: 0 0 15px rgba(255, 0, 255, 0.1);
            margin-bottom: 1rem;
        }}
        
        .dashboard-card {{
            background: {surface} !important;
            border: 1px solid rgba(255, 0, 127, 0.3) !important;
            border-radius: 16px !important;
            padding: 1.2rem !important;
            box-shadow: 0 8px 32px rgba(255, 0, 127, 0.15) !important;
            backdrop-filter: blur(8px);
            margin-bottom: 1rem;
        }}
        
        .chat-content-area {{ 
            padding: 2rem; 
            border-radius: 24px; 
            background: {surface}; 
            box-shadow: 0 20px 60px rgba(255, 0, 255, 0.15); 
            border: 1px solid rgba(255, 0, 255, 0.3); 
            backdrop-filter: blur(10px);
            margin-top: 1rem;
        }}
        
        .chat-bubble-user, .chat-bubble-assistant {{ max-width: 85%; padding: 1rem 1.2rem; border-radius: 22px; box-shadow: 0 10px 25px rgba(0,0,0,0.3); margin-bottom: 1rem; line-height: 1.7; }}
        .chat-bubble-user {{ margin-left: auto; background: rgba(255, 0, 127, 0.25) !important; border: 1px solid {accent}; color: #ffffff; }}
        .chat-bubble-assistant {{ margin-right: auto; background: rgba(15, 5, 30, 0.9) !important; border: 1px solid rgba(255, 255, 255, 0.15); color: #f8f7ff; }}
        
        .welcome-box {{
            text-align: center;
            max-width: 850px;
            margin: 0 auto;
            padding: 1rem 2rem;
            background: transparent;
        }}
        
        .stTextArea textarea {{
            background: #140526 !important;
            color: #ffffff !important;
            border: 1px solid rgba(255, 0, 255, 0.4) !important;
            border-radius: 12px !important;
            font-size: 1.05rem !important;
            box-shadow: 0 0 10px rgba(255, 0, 255, 0.1) inset;
        }}
        .stTextArea textarea:focus {{
            border-color: {accent2} !important;
            box-shadow: 0 0 15px rgba(255, 0, 255, 0.3) !important;
        }}
        
        div.stButton > button {{
            background: linear-gradient(135deg, {accent} 0%, {accent2} 100%) !important;
            color: #ffffff !important;
            border: none !important;
            border-radius: 10px !important;
            font-weight: 700 !important;
            box-shadow: 0 4px 15px rgba(255, 0, 127, 0.3) !important;
            transition: all 0.2s ease-in-out !important;
        }}
        div.stButton > button:hover {{
            transform: translateY(-2px) !important;
            box-shadow: 0 6px 20px rgba(255, 0, 255, 0.5) !important;
        }}
        
        ul, li, p {{ color: {secondary} !important; }}
        strong {{ color: #ffffff !important; }}
        </style>
    """
    st.markdown(custom_css, unsafe_allow_html=True)

def render_welcome_screen():
    render_ekg_animation()
    st.markdown("<div class='welcome-box'>", unsafe_allow_html=True)
    
    # ENFORCED CENTER ALIGNMENT FOR WELCOME LINES
    st.markdown("<h1 style='color: #ffffff; margin-bottom: 1.5rem; text-align: center; font-size: 2.5rem; font-weight: 800; letter-spacing: -0.02em; text-shadow: 0 0 15px #ff007f, 0 0 30px #ff00ff;'>Welcome to the Neon Medical & Fitness FAQ Assistant</h1>", unsafe_allow_html=True)
    st.markdown("<p style='color: #e2ccff; font-size: 1.15rem; line-height: 1.6; text-align: center; margin-bottom: 2.5rem;'>Your interactive gateway for secure, evidence-backed wellness, dynamic fitness tracking, and analytical query routing.</p>", unsafe_allow_html=True)
    
    c1, c2, c3 = st.columns([1, 2, 1])
    with c2:
        if st.button("🚀 Enter AI Dashboard", use_container_width=True, key="enter_dash"):
            st.session_state.dashboard_unlocked = True
            st.rerun()
    st.markdown("</div>", unsafe_allow_html=True)

def main():
    if 'dashboard_unlocked' not in st.session_state:
        st.session_state.dashboard_unlocked = False
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    if "selected_topic" not in st.session_state:
        st.session_state.selected_topic = None

    inject_custom_styles()

    if not st.session_state.dashboard_unlocked:
        render_welcome_screen()
    else:
        render_ekg_animation()
        st.markdown("<div class='neon-title'><h1>Medical & Fitness FAQ Assistant</h1></div>", unsafe_allow_html=True)

        layout_col1, layout_col2 = st.columns([6, 4])

        with layout_col1:
            st.markdown("### 💬 Ask a Question")
            user_query = st.text_area(
                "Query panel frame input box",
                key="main_dashboard_chat_input",
                height=115,
                label_visibility="collapsed",
                placeholder="Type your health or fitness question here..."
            )
            if st.button("Submit Question", use_container_width=True, type="primary"):
                if user_query and user_query.strip():
                    st.session_state.chat_history.append({"role": "user", "content": user_query})
                    response = get_ai_response(user_query)
                    st.session_state.chat_history.append({"role": "assistant", "content": response})
                    st.rerun()
                else:
                    st.warning("Please type an inquiry block first before submitting.")

        with layout_col2:
            st.markdown("### 🎯 Filter Content Categories")
            st.markdown("<div class='category-scroll-box'>", unsafe_allow_html=True)
            if st.button("Reset Filter (Show All)", use_container_width=True, key="reset_filter_dash"):
                st.session_state.selected_topic = None
                st.rerun()
            for category in FAQ_CATEGORIES:
                button_label = f"📍 {category}"
                if st.button(button_label, use_container_width=True, key=f"dash_pill_{category}"):
                    st.session_state.selected_topic = category
                    st.rerun()
            st.markdown("</div>", unsafe_allow_html=True)

        st.markdown("---")

        m_col1, m_col2, m_col3 = st.columns(3)
        
        with m_col1:
            st.markdown("<div class='dashboard-card'>", unsafe_allow_html=True)
            st.markdown("<h3 style='margin-top:0;'>📋 Available Topics</h3>", unsafe_allow_html=True)
            summary_html = "".join([f"<li><strong>{cat}</strong> ({len([e for e in FAQ_DATA if e['category']==cat])} guides available)</li>" for cat in FAQ_CATEGORIES])
            st.markdown(f"<ul style='padding-left:15px; margin-bottom:0;'>{summary_html}</ul>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
            
        with m_col2:
            st.markdown("<div class='dashboard-card' style='height: 100%;'>", unsafe_allow_html=True)
            st.markdown("<h3 style='margin-top:0;'>🔒 Safe Usage Guide</h3>", unsafe_allow_html=True)
            st.markdown("<p style='margin-bottom:0; line-height:1.6;'>This application functions as an automated educational index for basic health and fitness inquiries. It is designed to provide immediate answers to general questions regarding recovery, nutritional profiles, and active lifestyle goals.</p>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)
            
        with m_col3:
            st.markdown("<div class='dashboard-card' style='height: 100%;'>", unsafe_allow_html=True)
            st.markdown("<h3 style='margin-top:0;'>⚠️ Professional Disclaimer</h3>", unsafe_allow_html=True)
            st.markdown("<p style='margin-bottom:0; line-height:1.6;'>Information rendered by this chatbot does not constitute formal clinical evaluation. For persistent symptoms, serious diagnostic workflows, physical injuries, or tailored medical adjustments, please schedule a direct consultation with a licensed healthcare practitioner.</p>", unsafe_allow_html=True)
            st.markdown("</div>", unsafe_allow_html=True)

        if st.session_state.selected_topic:
            st.markdown("<div class='chat-content-area'>", unsafe_allow_html=True)
            st.markdown(f"### Active Dashboard Filter: <span style='color:#ff00ff; text-shadow: 0 0 10px #ff00ff;'>{st.session_state.selected_topic}</span>", unsafe_allow_html=True)
            filtered_faqs = [entry for entry in FAQ_DATA if entry["category"] == st.session_state.selected_topic]
            for faq in filtered_faqs:
                with st.expander(f"❓ {faq['question']}"):
                    st.write(faq['answer'])
            st.markdown("</div>", unsafe_allow_html=True)

        if not st.session_state.chat_history:
            st.info("👋 Welcome! Type an inquiry inside the text block above to interact with your Medical Knowledge Base.")
        else:
            st.markdown("<div class='chat-content-area'>", unsafe_allow_html=True)
            st.markdown("### 💬 Active Consultation Thread")
            for item in st.session_state.chat_history:
                align = "flex-end" if item["role"] == "user" else "flex-start"
                bubble_class = "chat-bubble-user" if item["role"] == "user" else "chat-bubble-assistant"
                sender_title = "You" if item["role"] == "user" else "Assistant AI"
                st.markdown(
                    f"<div style='display:flex; justify-content:{align}; margin-bottom: 0.5rem;'>"
                    f"<div class='{bubble_class}'>"
                    f"<strong style='color: #ff00ff;'>{sender_title}</strong><br>{item['content']}</div></div>",
                    unsafe_allow_html=True,
                )
            st.markdown("</div>", unsafe_allow_html=True)

if __name__ == "__main__":
    initialize_vectorizer()
    main()