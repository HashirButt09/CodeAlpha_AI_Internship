# AI Internship Tasks Repository

This repository contains internship projects completed as part of the AI development track. The projects are modular, well-structured, and designed with high-fidelity, interactive user interfaces built with Streamlit and modern CSS/Three.js styling.

---

## 📁 Repository Structure

```text
ai-internship-tasks/
├── .gitignore                    # Root rules for Git exclusions
├── README.md                     # Root repository guide (this file)
├── task_1/                       # Module for Task 1: AI Language Translator
│   ├── .venv/                    # Local Python virtual environment for Task 1
│   ├── .gitignore                # Task 1 local Git exclusions (virtual env, caches)
│   ├── requirements.txt          # Python library dependencies for Task 1
│   ├── run_app.bat               # Windows batch script to run Task 1 instantly
│   ├── translator_app_main.py    # Main Streamlit application file
│   └── README.md                 # Detailed guide for Task 1
└── task_2/                       # Module for Task 2: Medical & Fitness FAQ Chatbot
    ├── venv/                     # Local Python virtual environment for Task 2
    ├── .gitignore                # Task 2 local Git exclusions (virtual env, caches, logs)
    ├── requirements.txt          # Python library dependencies for Task 2
    ├── run_app.bat               # Windows batch script to run Task 2 instantly
    ├── app.py                    # Main Streamlit chatbot application file
    └── README.md                 # Detailed guide for Task 2
```

---

## 🚀 Projects Overview & Quick Run

### [Task 1: AI Language Translator](file:///d:/Ai_internship_tasks/task_1)
A premium translation application featuring:
*   Multi-language translation with auto-language detection support using `deep-translator`.
*   Interactive Text-to-Speech (TTS) integration with audio playback and `.mp3` downloads using `gTTS`.
*   Smooth animations, dark/light theme options, and a stunning 3D header canvas utilizing Three.js.
*   **Quick Run (Windows):** Run `run_app.bat` inside [task_1/](file:///d:/Ai_internship_tasks/task_1).
*   *For details, view the [Task 1 README](file:///d:/Ai_internship_tasks/task_1/README.md).*

### [Task 2: Medical & Fitness FAQ Chatbot](file:///d:/Ai_internship_tasks/task_2)
An interactive educational chatbot featuring:
*   Natural Language Processing (NLP) tokenization, stopwords filtering, and lemmatization using `nltk`.
*   Cosine similarity-based query routing using `scikit-learn` TF-IDF vectors for fast matching.
*   Vibrant neon-themed UI, including custom EKG pulse animations, category selectors, expandable diagnostic cards, and persistent session state chat logs.
*   **Quick Run (Windows):** Run `run_app.bat` inside [task_2/](file:///d:/Ai_internship_tasks/task_2).
*   *For details, view the [Task 2 README](file:///d:/Ai_internship_tasks/task_2/README.md).*

---

## 🛠️ General Environment Setup (Manual)

If you wish to configure the virtual environments or run the applications manually on any operating system, follow these general steps:

### Prerequisites
*   **Python 3.8 to 3.11** installed on your system.
*   `pip` (Python Package Installer) up to date.

### Step-by-Step Installation

1.  **Clone the Repository:**
    ```bash
    git clone <your-repository-url>
    cd ai-internship-tasks
    ```

2.  **Navigate and Setup Task 1:**
    ```bash
    cd task_1
    python -m venv .venv
    # Activate virtual environment
    # On Windows:
    .venv\Scripts\activate
    # On macOS/Linux:
    source .venv/bin/activate
    
    # Install dependencies
    pip install -r requirements.txt
    
    # Launch application
    streamlit run translator_app_main.py
    ```

3.  **Navigate and Setup Task 2:**
    ```bash
    cd ../task_2
    python -m venv venv
    # Activate virtual environment
    # On Windows:
    venv\Scripts\activate
    # On macOS/Linux:
    source venv/bin/activate
    
    # Install dependencies
    pip install -r requirements.txt
    
    # Launch application
    streamlit run app.py
    ```

---

## 📝 License
This project is private and intended solely for internship task submissions.
