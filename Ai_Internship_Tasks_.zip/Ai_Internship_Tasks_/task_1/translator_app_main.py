import io
import sys
import subprocess
import importlib

import streamlit as st
import streamlit.components.v1 as components
from deep_translator import GoogleTranslator

try:
    from gtts import gTTS
    gtts_available = True
except ImportError:
    gtts_available = False

if 'theme' not in st.session_state:
    st.session_state.theme = 'dark'


def set_theme(theme):
    st.session_state.theme = theme


def apply_theme_styles():
    theme = st.session_state.theme
    if theme == 'light':
        bg1 = '#f2f7ff'
        bg2 = '#e8eff9'
        bg3 = '#dce4ed'
        text = '#0f172a'
        panel = 'rgba(255,255,255,0.88)'
        field_bg = 'rgba(255,255,255,0.98)'
        border_color = 'rgba(15,23,42,0.16)'
        placeholder_color = 'rgba(15,23,42,0.45)'
        button_light = '#7c3aed'
        button_dark = '#06b6d4'
        secondary = '#11427a'
    else:
        bg1 = '#071021'
        bg2 = '#071c2a'
        bg3 = '#061126'
        text = '#e6eef8'
        panel = 'rgba(255,255,255,0.08)'
        field_bg = 'rgba(15,23,42,0.95)'
        border_color = 'rgba(255,255,255,0.18)'
        placeholder_color = 'rgba(230,238,248,0.72)'
        button_light = '#7c3aed'
        button_dark = '#06b6d4'
        secondary = '#c7d2fe'

    st.markdown(f'''
    <style>
        #MainMenu {{visibility: hidden;}}
        footer {{visibility: hidden;}}
        header {{visibility: hidden;}}
        .css-1outpf7 {{visibility: hidden;}}
        .stApp {{background: linear-gradient(120deg, {bg1} 0%, {bg2} 50%, {bg3} 100%);}}
        .stApp, .stApp * {{color: {text} !important;}}
        input, textarea, select, .stTextInput input, .stTextArea textarea, .stSelectbox div, .stMultiSelect div, .stNumberInput input, .stDateInput input {{
            color: {text} !important;
            background: {field_bg} !important;
            border-color: {border_color} !important;
        }}
        input::placeholder, textarea::placeholder, select::placeholder {{ color: {placeholder_color} !important; }}
        option {{ color: {text} !important; background: {field_bg} !important; }}
        .stTextInput>div>label, .stTextArea>div>label, .stSelectbox>label, .css-1x0uki1 {{color: {text} !important;}}
        .stAlert {{background: rgba(255,255,255,0.06) !important; color: {text} !important; border-color: rgba(255,255,255,0.14) !important;}}
        .css-1f4mp12, .css-1r6slb0, .css-1x0uki1 {{color: {text} !important;}}
        #animated-bg {{background: linear-gradient(120deg, {bg1} 0%, {bg2} 50%, {bg3} 100%) !important;}}
        #animated-bg:before {{background: radial-gradient(circle at 10% 20%, rgba(99,102,241,0.12), transparent 8%),
                               radial-gradient(circle at 90% 80%, rgba(236,72,153,0.10), transparent 8%),
                               radial-gradient(circle at 50% 50%, rgba(34,197,94,0.06), transparent 8%) !important;}}
        .app-box {{background: {panel}; box-shadow: 0 10px 40px rgba(0,0,0,0.18);}}
        h1, h2, .css-1v3fvcr, .streamlit-expanderHeader {{color: {text};}}
        .stButton>button, button {{color: white;}}
        .stButton>button, .fancy-action-btn {{box-shadow: 0 10px 30px rgba(0,0,0,0.18);}}
        .fancy-action-btn.copy-btn {{background: linear-gradient(135deg, {button_light} 0%, {button_dark} 100%);}}
        .fancy-action-btn.play-btn {{background: linear-gradient(135deg, {button_dark} 0%, {button_light} 100%);}}
        .streamlit-expanderHeader {{text-shadow: none;}}
    </style>
    <script>
        document.body.className = '{theme}';
    </script>
    ''', unsafe_allow_html=True)


def install_gtts():
    st.info("Installing gTTS into the active Python environment...")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "gTTS"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        try:
            importlib.invalidate_caches()
            gtts_module = importlib.import_module("gtts")
            globals()["gTTS"] = getattr(gtts_module, "gTTS")
            global gtts_available
            gtts_available = True
            st.success("gTTS installed successfully. Click Play Audio again.")
            return True
        except Exception as imp_err:
            st.error(f"Installed gTTS but import failed: {imp_err}")
            return False
    else:
        st.error("Failed to install gTTS. See output below.")
        st.code(result.stderr or result.stdout)
        return False

# --- Page Configuration ---
st.set_page_config(page_title="AI Translator", page_icon="🌐", layout="centered")

apply_theme_styles()

# --- UI Header ---
# Inject animated background CSS, floating orbs, and button styles
st.markdown("""
<style>
:root { --glass: rgba(255,255,255,0.06); }
#animated-bg {
  position: fixed;
  inset: 0;
  z-index: -1;
  background: linear-gradient(120deg, #071021 0%, #071c2a 50%, #061126 100%);
  overflow: hidden;
}
#animated-bg:before { content:""; position:absolute; width:200%; height:200%; left:-50%; top:-50%;
 background: radial-gradient(circle at 10% 20%, rgba(99,102,241,0.12), transparent 8%),
             radial-gradient(circle at 90% 80%, rgba(236,72,153,0.10), transparent 8%),
             radial-gradient(circle at 50% 50%, rgba(34,197,94,0.06), transparent 8%);
 animation: bgShift 14s linear infinite;
 transform: rotate(0.001deg);
}
@keyframes bgShift { 0%{transform:translate(0,0) rotate(0deg);}50%{transform:translate(10%,6%) rotate(25deg);}100%{transform:translate(0,0) rotate(0deg);} }
.orb { position:absolute; border-radius:50%; filter: blur(36px); opacity:0.85; animation: float 9s ease-in-out infinite; mix-blend-mode: screen; }
.orb.o1{width:380px;height:380px; left:5%; top:6%; background: radial-gradient(circle, #facc15 0%, #f97316 85%); opacity:0.96;}
.orb.o2{width:240px;height:240px; right:8%; top:18%; background: radial-gradient(circle, #8b5cf6 0%, #ec4899 85%); animation-duration:12s; opacity:0.96;}
.orb.o3{width:200px;height:200px; left:30%; bottom:8%; background: radial-gradient(circle, #22c55e 0%, #14b8a6 85%); animation-duration:11s; opacity:0.96;}
@keyframes float { 0%{transform:translateY(0);}50%{transform:translateY(-36px);}100%{transform:translateY(0);} }

/* Glass panel for app content */
.app-box { background: linear-gradient(135deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01)); border-radius:18px; padding:18px; box-shadow: 0 10px 40px rgba(2,6,23,0.6); border: 1px solid rgba(255,255,255,0.03); }

/* Buttons */
.stButton>button, button { background: linear-gradient(90deg,#7c3aed,#06b6d4); color: white; padding:10px 18px; border-radius:12px; border:none; box-shadow: 0 8px 28px rgba(99,102,241,0.18); transition: transform .18s ease, box-shadow .18s ease; font-weight:700; }
.stButton>button:hover, button:hover { transform: translateY(-4px) scale(1.02); box-shadow: 0 18px 36px rgba(99,102,241,0.28); cursor:pointer; }

/* Make code block look modern */
.stCodeBlock pre { background: rgba(0,0,0,0.45); border-radius:10px; padding:12px; color:#e6edf3; }

/* Tweak header */
h1, h2, .css-1v3fvcr, .streamlit-expanderHeader { text-shadow: 0 2px 18px rgba(0,0,0,0.6); color: #e6eef8; }
.hero-title { position: relative; z-index: 1; display: flex; justify-content: center; padding-top: 1.2rem; margin-bottom: 0.75rem; }
.animated-heading { margin: 0; font-size: clamp(2.4rem, 7vw, 4rem); font-weight: 900; text-transform: none; letter-spacing: 0.12em; line-height: 1; background: linear-gradient(90deg, #a5b4fc 0%, #ffffff 45%, #f472b6 100%); -webkit-background-clip: text; color: transparent; animation: glowPulse 3.5s ease-in-out infinite; }
.animated-heading .highlight { background: linear-gradient(90deg, #7c3aed 0%, #22d3ee 100%); -webkit-background-clip: text; color: transparent; }
.animated-heading::after { content: ""; width: 120px; height: 4px; display: block; margin: 14px auto 0; border-radius: 999px; background: linear-gradient(90deg, #7c3aed, #06b6d4); box-shadow: 0 0 20px rgba(124,58,237,0.25); }
@keyframes glowPulse { 0%, 100% { text-shadow: 0 0 12px rgba(124,58,237,0.35), 0 0 24px rgba(56,189,248,0.2); transform: translateY(0px); }
  50% { text-shadow: 0 0 24px rgba(124,58,237,0.55), 0 0 36px rgba(56,189,248,0.3); transform: translateY(-4px); } }

.fancy-action-btn { display:inline-flex; align-items:center; justify-content:center; width:100%; height:48px; border:none; border-radius:14px; color:#fff; font-weight:700; letter-spacing:0.02em; transition: transform .18s ease, box-shadow .18s ease, filter .18s ease; }
.fancy-action-btn.copy-btn { background: linear-gradient(135deg, #38bdf8 0%, #60a5fa 100%); box-shadow: 0 10px 30px rgba(56,189,248,0.25); }
.fancy-action-btn.play-btn { background: linear-gradient(135deg, #f472b6 0%, #fbbf24 100%); box-shadow: 0 10px 30px rgba(251,191,36,0.22); }
.fancy-action-btn:hover { transform: translateY(-3px); filter: brightness(1.03); cursor: pointer; }
.fancy-action-btn:active { transform: translateY(-1px); }

@media (max-width: 600px) { .animated-heading { font-size: 2.2rem; } }

@media (max-width:600px){ .orb{display:none;} }
</style>

<div id="animated-bg" aria-hidden='true'>
  <div class='orb o1'></div>
  <div class='orb o2'></div>
  <div class='orb o3'></div>
</div>
<div class="hero-title">
  <h1 class="animated-heading">Language <span class="highlight">Translator</span></h1>
</div>
""", unsafe_allow_html=True)

# --- Small 3D animation (Three.js) for a "wow" header ---
light_colors = ["0x1d4ed8", "0x0ea5e9", "0xf97316", "0x047857", "0xea580c"]
dark_colors = ["0x7c3aed", "0x38bdf8", "0xf97316", "0x22c55e", "0xf472b6"]
marble_colors = light_colors if st.session_state.theme == 'light' else dark_colors
marble_colors_js = ",".join(marble_colors)
glass_color = "0x111827" if st.session_state.theme == 'dark' else "0xf8fafc"
components.html(f"""
<div id=\"threejs-root\" style=\"width:100%;height:220px;\"></div>
<script src=\"https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js\"></script>
<script>
    const container = document.getElementById('threejs-root');
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, container.clientWidth / 220, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({{antialias:true, alpha:true}});
    renderer.setSize(container.clientWidth, 220);
    renderer.setPixelRatio(window.devicePixelRatio);
    container.appendChild(renderer.domElement);

    const glassGeo = new THREE.SphereGeometry(1.6, 64, 64);
    const glassMat = new THREE.MeshPhysicalMaterial({{
        color: {glass_color},
        transparent: true,
        opacity: 0.14,
        roughness: 0.05,
        metalness: 0.9,
        transmission: 0.95,
        clearcoat: 1,
        clearcoatRoughness: 0.1,
        side: THREE.DoubleSide,
        envMapIntensity: 1.0,
    }});
    const glassSphere = new THREE.Mesh(glassGeo, glassMat);
    scene.add(glassSphere);

    const marblePositions = [
        [0.8, 0.3, 0.2],
        [-0.7, 0.4, -0.3],
        [0.25, -0.75, 0.5],
        [-0.35, -0.35, 0.9],
        [0.1, 0.65, -0.8],
        [-0.8, -0.2, -0.4],
        [0.6, -0.55, -0.6],
    ];

    const marbleMaterials = [{marble_colors_js}].map(color => new THREE.MeshStandardMaterial({{
        color: color,
        roughness: 0.18,
        metalness: 0.45,
        emissive: color,
        emissiveIntensity: 0.12,
    }}));

    const marbleGeo = new THREE.SphereGeometry(0.22, 32, 32);
    const marbleGroup = new THREE.Group();

    marblePositions.forEach((pos, index) => {{
        const marble = new THREE.Mesh(marbleGeo, marbleMaterials[index % marbleMaterials.length]);
        marble.position.set(pos[0], pos[1], pos[2]);
        marbleGroup.add(marble);
    }});

    scene.add(marbleGroup);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.45);
    scene.add(ambientLight);
    const keyLight = new THREE.PointLight(0xffffff, 1.2, 20);
    keyLight.position.set(4, 4, 6);
    scene.add(keyLight);
    const fillLight = new THREE.PointLight(0x88ccff, 0.55, 20);
    fillLight.position.set(-4, -2, 6);
    scene.add(fillLight);
    const rimLight = new THREE.PointLight(0xffd166, 0.35, 20);
    rimLight.position.set(0, 5, -5);
    scene.add(rimLight);

    camera.position.z = 5;

    function animate(){{
        requestAnimationFrame(animate);
        glassSphere.rotation.y += 0.006;
        marbleGroup.rotation.y -= 0.008;
        marbleGroup.rotation.x += 0.002;
        renderer.render(scene, camera);
    }}
    animate();
</script>
""", height=220)

# --- Translation Logic & Data ---
# Fetching the supported languages from the API
try:
    raw_langs = GoogleTranslator().get_supported_languages(as_dict=True)
    # Normalize display names to Title Case for UI and build a safe lookup dict
    langs_dict = {name.title(): code for name, code in raw_langs.items()}
    lang_names = list(langs_dict.keys())
except Exception:
    # Fallback if there's a connection issue during initialization
    lang_names = ["English", "Spanish", "French", "German", "Hindi", "Chinese (Simplified)"]
    langs_dict = {"English": "en", "Spanish": "es", "French": "fr", "German": "de", "Hindi": "hi", "Chinese (Simplified)": "zh-cn"}

# TTS language locale mapping for browser speech synthesis
tts_lang_map = {
    "English": "en-US",
    "Spanish": "es-ES",
    "French": "fr-FR",
    "German": "de-DE",
    "Hindi": "hi-IN",
    "Chinese (Simplified)": "zh-CN",
    "Arabic": "ar-SA",
    "Italian": "it-IT",
    "Japanese": "ja-JP",
    "Korean": "ko-KR",
    "Portuguese": "pt-PT",
    "Russian": "ru-RU",
    "Turkish": "tr-TR",
    "Dutch": "nl-NL",
    "Swedish": "sv-SE",
    "Indonesian": "id-ID",
    "Polish": "pl-PL",
    "Urdu": "ur-PK",
    "Vietnamese": "vi-VN"
}

gtts_lang_map = {
    "English": "en",
    "Spanish": "es",
    "French": "fr",
    "German": "de",
    "Hindi": "hi",
    "Chinese (Simplified)": "zh-cn",
    "Arabic": "ar",
    "Italian": "it",
    "Japanese": "ja",
    "Korean": "ko",
    "Portuguese": "pt",
    "Russian": "ru",
    "Turkish": "tr",
    "Dutch": "nl",
    "Swedish": "sv",
    "Indonesian": "id",
    "Polish": "pl",
    "Urdu": "ur",
    "Vietnamese": "vi"
}

# --- Initialize session state ---
if 'input_text' not in st.session_state:
    st.session_state.input_text = ""
if 'translated_text' not in st.session_state:
    st.session_state.translated_text = ""
if 'audio_bytes' not in st.session_state:
    st.session_state.audio_bytes = None
if 'play_clicked' not in st.session_state:
    st.session_state.play_clicked = False


def translate_text():
    if not st.session_state.input_text.strip():
        st.warning("Please enter some text to translate.")
        return
    try:
        src_code = "auto" if st.session_state.source_selection == "auto" else langs_dict.get(st.session_state.source_selection, "en")
        tar_code = langs_dict.get(st.session_state.target_selection, "en")
        st.session_state.translated_text = GoogleTranslator(source=src_code, target=tar_code).translate(st.session_state.input_text)
    except Exception as e:
        st.error(f"Translation Error: {e}")
    finally:
        st.session_state.audio_bytes = None


def generate_audio():
    if not gtts_available:
        st.error("gTTS is not installed in this Python environment. Run the app using the workspace venv or install gTTS first.")
        return

    if not st.session_state.translated_text:
        st.warning("Translate text first before generating audio.")
        return

    target_lang = st.session_state.target_selection
    gtts_lang = gtts_lang_map.get(target_lang, "en")
    try:
        tts_obj = gTTS(text=st.session_state.translated_text, lang=gtts_lang)
        mp3_bytes = io.BytesIO()
        tts_obj.write_to_fp(mp3_bytes)
        mp3_bytes.seek(0)
        st.session_state.audio_bytes = mp3_bytes.getvalue()
        st.session_state.play_clicked = True
    except Exception as e:
        st.error(f"Audio generation failed: {e}")
        st.session_state.audio_bytes = None
        st.session_state.play_clicked = False


def swap_languages():
    src = st.session_state.source_selection
    tar = st.session_state.target_selection
    if src != 'auto':
        st.session_state.source_selection = tar
        st.session_state.target_selection = src
    else:
        st.session_state.source_selection = tar
        st.session_state.target_selection = 'auto'


def clear_inputs():
    st.session_state.input_text = ""
    st.session_state.translated_text = ""


# --- User Interface Layout ---
mode_col1, mode_col2 = st.columns([1,1])
with mode_col1:
    if st.button("Light Mode", key='light_mode'):
        set_theme('light')
        apply_theme_styles()
with mode_col2:
    if st.button("Dark Mode", key='dark_mode'):
        set_theme('dark')
        apply_theme_styles()

col1, col2 = st.columns(2)

with col1:
    source_selection = st.selectbox("Source Language", options=["auto"] + lang_names, key='source_selection')

with col2:
    target_index = lang_names.index("Hindi") if "Hindi" in lang_names else 0
    target_selection = st.selectbox("Target Language", options=lang_names, index=target_index, key='target_selection')

# Input text area
input_text = st.text_area("Enter Text:", placeholder="Type your message here...", height=150, key='input_text')

# --- Action buttons row ---
btn_col1, btn_col2, btn_col3 = st.columns([1,1,1])
with btn_col1:
    st.button("Translate Now", on_click=translate_text)
with btn_col2:
    st.button("Swap Languages", on_click=swap_languages)
with btn_col3:
    st.button("Clear", on_click=clear_inputs)

if st.session_state.translated_text:
    st.success("Translation Complete!")
    st.subheader("Result:")
    st.info(st.session_state.translated_text)

    # Buttons for copy and TTS
    res_c1, res_c2 = st.columns([1,1])
    with res_c1:
        # Copy to clipboard via JS
        copy_html = f"""
        <button id='copy-btn' class='fancy-action-btn copy-btn'>Copy</button>
        <script>
          const btn = document.getElementById('copy-btn');
          btn.onclick = () => navigator.clipboard.writeText({st.session_state.translated_text!r});
        </script>
        """
        components.html(copy_html, height=60)
    with res_c2:
        if gtts_available:
            if st.button("Play Audio"):
                generate_audio()
        else:
            st.warning("gTTS is not available in this Python environment.")
            if st.button("Install gTTS"):
                install_gtts()

        if st.session_state.audio_bytes:
            st.success("Audio generated. Use the player below to listen.")
            st.audio(st.session_state.audio_bytes, format='audio/mpeg')
            st.download_button(
                label="Download Audio",
                data=st.session_state.audio_bytes,
                file_name="translation.mp3",
                mime="audio/mpeg",
            )
        elif st.session_state.play_clicked and gtts_available:
            st.warning("Audio generation did not produce sound. Check that the browser audio player is enabled.")

    st.markdown("---")
    st.write("### Copy Translation")
    st.code(st.session_state.translated_text, language=None)

# --- Footer ---
st.markdown("---")
st.markdown(
    "<div style='text-align:center; color:#94a3b8; font-size:13px; letter-spacing:0.04em;'>Professional AI Translator · Clean design · fast, reliable translation.</div>",
    unsafe_allow_html=True,
)