# Task 1: AI Language Translator

A professional, feature-rich translation dashboard designed with a highly responsive, modern glassmorphic interface, smooth theme switching, and an interactive 3D WebGL header.

---

## ✨ Features

*   **Premium Translation Engine:** Uses `deep-translator` wrapper around the Google Translate API, supporting dozens of languages with automated source language detection.
*   **Text-to-Speech (TTS):** Generates crystal-clear audio pronunciations for translation results in target languages via `gTTS`, directly supporting playback and audio downloads (`.mp3`).
*   **Modern Design Aesthetics:**
    *   Dynamic dark/light mode toggle with custom HSL-tailored colors.
    *   3D marble sphere animation utilizing `Three.js` that spins interactively.
    *   Responsive glass panels, floating background gradient orbs, and button click animations.
*   **Utility Actions:** Instant clipboard copying via JavaScript, input clearing, and source/target language swapping.
*   **Automatic Dependency Installation:** Includes automated installation scripts inside Streamlit to load missing `gTTS` dependencies on demand.

---

## 🚀 How to Run the App (Windows)

The simplest way to run the application on Windows is by using the pre-configured batch script:

1.  Navigate to the [task_1](file:///d:/Ai_internship_tasks/task_1) folder.
2.  Double-click the [run_app.bat](file:///d:/Ai_internship_tasks/task_1/run_app.bat) file.
3.  The application will automatically activate the local `.venv` environment, spin up the Streamlit server, and open the interface in your default web browser (typically at `http://localhost:8501`).

---

## 🛠️ Step-by-Step Manual Setup

If you prefer to configure the app manually or are running on macOS/Linux:

### 1. Prerequisites
Ensure you have **Python 3.8+** installed. You can verify this by running:
```bash
python --version
```

### 2. Set Up a Virtual Environment
Initialize a clean Python virtual environment to manage dependencies locally:
```bash
cd task_1
python -m venv .venv
```

### 3. Activate the Environment
*   **Windows (Command Prompt / PowerShell):**
    ```powershell
    .venv\Scripts\activate
    ```
*   **macOS / Linux:**
    ```bash
    source .venv/bin/activate
    ```

### 4. Install Dependencies
Install all required libraries specified in [requirements.txt](file:///d:/Ai_internship_tasks/task_1/requirements.txt):
```bash
pip install -r requirements.txt
```

### 5. Launch the Streamlit App
Run the main script:
```bash
streamlit run translator_app_main.py
```

---

## 📦 Dependencies

*   `streamlit` - Web framework for layout and components.
*   `deep-translator` - Connects to the translation API.
*   `gTTS` - Text-to-Speech library (optional/installable dynamically via the UI if missing).

---

## 🔍 Troubleshooting

*   **gTTS Import Warning:** If the web app warns that `gTTS` is not available, click the **"Install gTTS"** button directly in the web UI. This triggers a subprocess to install it into your active virtual environment. After installation, click "Play Audio" again.
*   **Port already in use:** If port `8501` is occupied, Streamlit will automatically try `8502`, `8503`, etc. Keep an eye on your command line output for the active URL.
