# Medical & Fitness FAQ Chatbot Assistant

An interactive, evidence-backed medical and fitness FAQ assistant built with **Streamlit**, **Scikit-learn**, and **NLTK**. The chatbot parses user questions, computes TF-IDF vector similarity against a precompiled expert FAQ knowledge base, and serves answers dynamically within a premium, responsive neon-themed dark mode user interface.

## Features

- **Consultation Chatbot Thread**: Interact in real-time with the chatbot using similarity matching.
- **Dynamic Content Filtering**: Filter FAQ categories (General Health, Nutrition, Fitness, Injury, Mental Wellness) on the fly.
- **Custom EKG Pulse Animation**: High-fidelity custom SVG pulse animation for medical aesthetics.
- **Safe Usage and Disclaimer Guides**: Dedicated panels displaying safe usage guidelines and professional clinical disclaimers.

---

## Prerequisites

- **Python**: Version `3.8` to `3.11` (Python `3.11.9` is tested and recommended).
- **Git** (optional, for cloning the repository).

---

## Installation & Setup (Step-by-Step)

Follow these steps to set up and run the project on any Windows, macOS, or Linux device.

### 1. Clone or Copy the Project
Ensure all task files are in your desired working directory.

### 2. Create a Virtual Environment
Isolate the project dependencies by creating a virtual environment.

- **Windows (PowerShell)**:
  ```powershell
  python -m venv venv
  ```
- **macOS / Linux**:
  ```bash
  python3 -m venv venv
  ```

### 3. Activate the Virtual Environment
Activate the environment to use the local Python and Pip instances.

- **Windows (PowerShell)**:
  ```powershell
  .\venv\Scripts\Activate.ps1
  ```
- **Windows (Command Prompt)**:
  ```cmd
  .\venv\Scripts\activate.bat
  ```
- **macOS / Linux**:
  ```bash
  source venv/bin/activate
  ```

### 4. Install Dependencies
Install all required libraries using the provided `requirements.txt`:
```bash
pip install -r requirements.txt
```

---

## Running the Application

With the virtual environment activated, run the Streamlit application:

```bash
streamlit run app.py
```

After startup, your default web browser should open automatically. If it does not, navigate manually to:
- **Local URL**: `http://localhost:8501`

---

## Project Structure

- `app.py`: Core application code containing the UI, style overrides, vectorizer, and matching logic.
- `requirements.txt`: Project package dependencies list.
- `app_error.log`: Log file containing application events and debug traces (automatically generated).
- `.gitignore`: Rules specifying which local directories and log files Git should ignore.
