@echo off
cd /d "%~dp0"

if not exist venv (
    echo Virtual environment venv not found. Creating it now...
    python -m venv venv
    if errorlevel 1 (
        echo Error: Python is not installed or not in your PATH.
        echo Please install Python 3.8+ and add it to your system PATH.
        pause
        exit /b 1
    )
    echo Installing dependencies from requirements.txt...
    venv\Scripts\pip install -r requirements.txt
    if errorlevel 1 (
        echo Error: Failed to install dependencies.
        pause
        exit /b 1
    )
)

echo Starting the Streamlit app...
venv\Scripts\python.exe -m streamlit run app.py
